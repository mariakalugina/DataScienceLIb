import scrapy
from scrapy.http import HtmlResponse
from lmru.lmru.items import LmruItem
from scrapy.loader import ItemLoader
import pprint

class LmspiderSpider(scrapy.Spider):
    name = 'lmspider'
    allowed_domains = ['leroymerlin.ru']
    start_urls = ['http://leroymerlin.ru/']

    def __init__(self, query):
        super(LmspiderSpider, self).__init__()

        self.start_urls = [f'https://leroymerlin.ru/search/?q={query}']

    def parse(self, response:HtmlResponse):
        #//product-card
        goods_links = response.xpath('//product-card/@data-product-url').extract()

        for link in goods_links:
            yield response.follow(link, callback=self.parse_good)
        next_page = response.xpath('//a[@rel="next"]/@href').extract_first()
        if next_page:
            yield response.follow(next_page, callback=self.parse)


    def parse_good(self, response:HtmlResponse):
        loader = ItemLoader(item=LmruItem(), response=response)
        loader.add_xpath('name', '//h1/text()')
        loader.add_xpath('photos', '//img[@slot ="thumbs"]/@src')
        loader.add_xpath('price', '//meta[@itemprop ="price"]/@content')
        loader.add_xpath('params', '//div[@class="def-list__group"]')#/dt/text()')
        loader.add_value('url', response.url)
        yield loader.load_item()
        #name = response.xpath('//h1/text()').extract_first()
        #photos=response.xpath('//img[@slot ="thumbs"]/@src').extract()
        #yield LmruItem(name=name, photos=photos)
