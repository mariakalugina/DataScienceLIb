# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
from itemloaders.processors import MapCompose, TakeFirst

def process_url(value):
    if value:
        value = value.replace('w_82,h_82', 'w_1000,h_1000')
    return value

def process_price(value):
    if value:
        try:
            value = float(value)
        except:
            value=None
    return value

#def process_params(value):
#    if value:
#        new_dict = {}
#        list = value.split('\n') #1 3
#        #значение парамерта для словаря
#        val = list[3]
#        val = val.replace('  ', '')
#        # ключ парамерта для словаря
#        key= list[1]
#        try:
#                key = key.replace('rj', '')
#                key = key.replace('</dt>', '')
#                key = key.replace('  ','')
#                new_dict[key] = val
#
#        except:
#            pass
#    return new_dict
def process_params(value):
    if value:
        value = value.replace('\n', '')
        value = value.replace('  ', '')
    return value


class LmruItem(scrapy.Item):
    # define the fields for your item here like:
    _id = scrapy.Field()
    name = scrapy.Field(output_processor=TakeFirst())
    photos = scrapy.Field(input_processor=MapCompose(process_url))
    price = scrapy.Field(output_processor=TakeFirst(),input_processor=MapCompose(process_price))
    #params = scrapy.Field(input_processor=MapCompose(process_params) )
    params_keys = scrapy.Field(output_processor=MapCompose(process_params))
    params_values = scrapy.Field(output_processor=MapCompose(process_params))
    params = scrapy.Field()


    url = scrapy.Field(output_processor=TakeFirst())
    #name = scrapy.Field()
    #photos = scrapy.Field()
    #url = scrapy.Field()