# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from scrapy.pipelines.images import ImagesPipeline
from pymongo import MongoClient
import  PIL as pillow
from PIL import Image
import hashlib
import datetime
from scrapy.utils.python import to_bytes

import scrapy

class LmruPipeline:
    def __init__(self):
        client = MongoClient('localhost', 27017)
        self.mongo_base = client.leroymerlin2903


    def process_item(self, item, spider):
        collection = self.mongo_base[spider.name]
        collection.insert_one(item)
        return item

class LmruPhotosPipeLine(ImagesPipeline):
    def get_media_requests(self, item, info):
        if item['photos']:
            for img in item['photos']:

                try:
                    yield scrapy.Request(img) #это для лоадера
                    #yield scrapy.Request(img.replace('w_82,h_82', 'w_1000,h_1000'))
                except:
                    print('!')

    def file_path(self, request, response=None, info=None, *, item=None):
        image_guid = hashlib.sha1(to_bytes(request.url)).hexdigest()
        return f'full/{item["name"]}/{image_guid}.jpg'

    def item_completed(self, results, item, info):
        if results:
            item['photos']=[itm[1] for itm in results if itm[0]]
        return item