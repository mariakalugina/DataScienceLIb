# This is a sample Python script.

# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.
from pymongo import MongoClient
from pprint import pprint


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press ⌘F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':

    # не знала, где написать запрос в базу данных - и сделала это здесь
    client = MongoClient('localhost', 27017)
    mongo_base = client.insta0104

    user_for_search = input('Введите логин пользователя для поиска его подписчиков:')
    collection = mongo_base['followers']
    followers = collection.find({'user_name': user_for_search})
    for follower in followers:
        pprint(follower)

    user_for_search = input('Введите логин пользователя для поиска его подписок:')
    collection = mongo_base['leaders']
    leaders = collection.find({'user_name': user_for_search})
    for leader in leaders:
        pprint(leader)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
