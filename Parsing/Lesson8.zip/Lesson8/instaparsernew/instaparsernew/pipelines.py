# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from pymongo import MongoClient


class InstaparsernewPipeline:

    def __init__(self):
        client = MongoClient('localhost', 27017)
        self.mongo_base = client.insta0104



    def process_item(self, item, spider):
        if item['is_follower']:
            collection = self.mongo_base['followers']
        else:
            collection = self.mongo_base['leaders']
        collection.insert_one(item)
        return item