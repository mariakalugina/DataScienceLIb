# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class InstaparsernewItem(scrapy.Item):
    # define the fields for your item here like:
    _id = scrapy.Field()
    user_id = scrapy.Field()
    user_name = scrapy.Field()
    follower_id =scrapy.Field()
    follower_username = scrapy.Field()
    follower_full_name = scrapy.Field()
    photo = scrapy.Field()
    info = scrapy.Field()
    #это поле показывает, является ли айтем фолловером исследуемого пользователя.
    #если False = это значит, что на этот аккаунт из списка подписок
    is_follower = scrapy.Field()
