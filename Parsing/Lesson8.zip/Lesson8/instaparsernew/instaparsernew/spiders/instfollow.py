import scrapy
from scrapy.http import HtmlResponse
from instaparsernew.instaparsernew.items import InstaparsernewItem
import re
import json
from urllib.parse import urlencode
from copy import deepcopy
class InstfollowSpider(scrapy.Spider):
    name = 'instfollow'
    allowed_domains = ['instagram.com']
    start_urls = ['https://www.instagram.com']

    insta_login = 'gb_education' #id 46955976506
    insta_pwd = '#PWD_INSTAGRAM_BROWSER:10:1617188969:AT5QAMNEdilFKd8yq48EkZVS6Gs0rYqPCbH8dIcHRsY7A0gG1NziQ0f8mkOsoLsqV4L0KiYXhSTlcbUEmiCKvPCwPkzvCQ3HX+r5LcIEv1ced5zB+FXtQMu2jAklymut7agxo1m5Jx5r7rimbA=='
    inst_login_link = 'https://www.instagram.com/accounts/login/ajax/'
    #parse_user1 = 'evgeniyandreev'  # Пользователь, у которого собираем посты. Можно указать список
    #parse_user2 = 'nastya_andreeva'
    users_list = ['spine_is_mine', 'moonlight.fingers']
    graphql_url = 'https://www.instagram.com/graphql/query/?'
    posts_hash = 'eddbde960fed6bde675388aac39a3657'  # hash для получения данных по постах с главной стр
    followers_hash = '5aefa9893005572d237da5068082d8d5'# hash для получения данных по подписчиках
    following_hash = '3dec7e2c57367ef3da3d987d89f9dbc8'# hash для получения данных по подписках

    def parse(self, response):
        csrf_token = self.fetch_csrf_token(response.text)  # csrf token забираем из html
        yield scrapy.FormRequest(  # заполняем форму для авторизации
            self.inst_login_link,
            method='POST',
            callback=self.user_parse,
            formdata={'username': self.insta_login, 'enc_password': self.insta_pwd},
            headers={'X-CSRFToken': csrf_token}
        )

    def user_parse(self, response:HtmlResponse):
        j_body = json.loads(response.text)
        if j_body['authenticated']:  #Проверяем ответ после авторизации
            for each_user in self.users_list:
                yield response.follow(
                    # Переходим на желаемую страницу пользователя. Сделать цикл для кол-ва пользователей больше 2-ух
                    f'/{each_user}',
                    callback=self.user_data_parse,
                    cb_kwargs={'username': each_user}
                )

    def user_data_parse(self, response:HtmlResponse, username):
        user_id = self.fetch_user_id(response.text, username)       #Получаем id пользователя
        variables={'id':user_id,                                    #Формируем словарь для передачи даных в запрос
                   'first':12}                                      #12 постов. Можно больше (макс. 50)
        url_followers = f'{self.graphql_url}query_hash={self.followers_hash}&{urlencode(variables)}'    #Формируем ссылку для получения данных о постах
        yield response.follow(
            url_followers,
            callback=self.user_followers_parse,
            cb_kwargs={'username':username,
                       'user_id':user_id,
                       'variables':deepcopy(variables)}         #variables ч/з deepcopy во избежание гонок
        )
        url_leaders = f'{self.graphql_url}query_hash={self.following_hash}&{urlencode(variables)}'
        yield response.follow(
            url_leaders,
            callback=self.user_leaders_parse,
            cb_kwargs={'username': username,
                       'user_id': user_id,
                       'variables': deepcopy(variables)}  # variables ч/з deepcopy во избежание гонок
        )




    def user_followers_parse(self, response: HtmlResponse, username, user_id,
                         variables):  # Принимаем ответ. Не забываем про параметры от cb_kwargs
        j_data = json.loads(response.text)
        try:
            page_info = j_data.get('data').get('user').get('edge_followed_by').get('page_info')
        except:
            pass
        try:
            page_info = j_data.get('data').get('user').get('edge_owner_to_timeline_media').get('page_info')
        except:
            pass

        if page_info.get('has_next_page'):  # Если есть следующая страница
            variables['after'] = page_info['end_cursor']  # Новый параметр для перехода на след. страницу
            url_posts = f'{self.graphql_url}query_hash={self.followers_hash}&{urlencode(variables)}'
            yield response.follow(
                url_posts,
                callback=self.user_followers_parse,
                cb_kwargs={'username': username,
                           'user_id': user_id,
                           'variables': deepcopy(variables)}
            )
        followers = j_data.get('data').get('user').get('edge_followed_by').get('edges')  # Сами посты
        for follower in followers:  # Перебираем посты, собираем данные
            item = InstaparsernewItem(
                user_id=user_id,
                user_name=username,
                follower_username = follower['node']['username'],
                follower_id = follower['node']['id'],
                follower_full_name = follower['node']['full_name'],
                photo=follower['node']['profile_pic_url'],
                is_follower = True

            )
            yield item  # В пайплайн
        return

        #обрабатываем подписки
    def user_leaders_parse(self, response: HtmlResponse, username, user_id,
                                 variables):  # Принимаем ответ. Не забываем про параметры от cb_kwargs
            j_data = json.loads(response.text)
            try:
                page_info = j_data.get('data').get('user').get('edge_follow').get('page_info')
            except:
                pass
            try:
                page_info = j_data.get('data').get('user').get('edge_owner_to_timeline_media').get('page_info')
            except:
                pass
            if page_info.get('has_next_page'):  # Если есть следующая страница
                variables['after'] = page_info['end_cursor']  # Новый параметр для перехода на след. страницу
                url_leaders= f'{self.graphql_url}query_hash={self.following_hash}&{urlencode(variables)}'
                yield response.follow(
                    url_leaders,
                    callback=self.user_leaders_parse,
                    cb_kwargs={'username': username,
                               'user_id': user_id,
                               'variables': deepcopy(variables)}
                )
            leaders = j_data.get('data').get('user').get('edge_follow').get('edges')  # Сами посты
            for leader in leaders:  # Перебираем посты, собираем данные
                item = InstaparsernewItem(
                    user_id=user_id,
                    user_name=username,
                    follower_username=leader['node']['username'],
                    follower_id=leader['node']['id'],
                    follower_full_name=leader['node']['full_name'],
                    photo=leader['node']['profile_pic_url'],
                    is_follower = False

                )
                yield item  # В пайплайн
            return

        # Получаем токен для авторизации

    def fetch_csrf_token(self, text):
        matched = re.search('\"csrf_token\":\"\\w+\"', text).group()
        return matched.split(':').pop().replace(r'"', '')

        # Получаем id желаемого пользователя

    def fetch_user_id(self, text, username):
        matched = re.search(
            '{\"id\":\"\\d+\",\"username\":\"%s\"}' % username, text
        ).group()
        return json.loads(matched).get('id')